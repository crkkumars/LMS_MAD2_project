from flask import Flask
from flask_security import SQLAlchemyUserDatastore, Security
from flask_cors import CORS
from application.intialise import celery_init_app
from application.worker import daily_reminder, report
from celery.schedules import crontab


def create_app():

    from application.views import view
    from application.models import User, Role, db
    from application import intialise
    from werkzeug.security import generate_password_hash

    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///./model.db'
    app.config["SECRET_KEY"] = "ufgaeihiogjarbjvjear"
    app.config["CELERY"] = {"broker_url": "redis://localhost:6379",
                            "result_backend": "redis://localhost:6379"}

    db.init_app(app)
    datastore = SQLAlchemyUserDatastore(db, User, Role)
    app.security = Security(app, datastore)

    app.register_blueprint(view)

    CORS(app)

    with app.app_context():
        db.create_all()

        intialise.main()

    return app


app = create_app()

celery = celery_init_app(app)


@celery.on_after_configure.connect
def setup_periodic_tasks(sender, **kwargs):
    sender.add_periodic_task(10.0, daily_reminder.s(),
                             name='say hello every 10')
    sender.add_periodic_task(10.0, report.s(), name='say hello every 10')
    sender.add_periodic_task(crontab(day_of_month="*",
                                     hour=7,
                                     minute=0),
                             report.s(),
                             name='say hello every 10')

    app.conf.beat_schedule = {
        'daily-reminder': {
            'task': 'tasks.daily_reminder',
            'schedule': 10.0,                       # for every 10 seconds
            'args': (),
        },
    }
