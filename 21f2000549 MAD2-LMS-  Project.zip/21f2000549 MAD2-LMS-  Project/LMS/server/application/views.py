import re
import os
import base64
from .worker import export_pdf
from .models import db, Section, Genre, SectionGenre, Status, Book, Register, User, Feedback
from datetime import datetime, date, timedelta
from flask import Blueprint, request, send_file
from flask import current_app as app
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from flask_security import login_user, auth_required, roles_required, current_user
from sqlalchemy import and_, or_
from io import BytesIO
from celery.result import AsyncResult


view = Blueprint("view", __name__)


@view.route("/register", methods=["POST"])
def index():
    firstname = request.json.get("firstname")
    lastname = request.json.get("lastname")
    email = request.json.get("email", "")
    mobile = request.json.get("mobile")
    password = request.json.get("password")
    confirm = request.json.get("confirm")

    if not firstname:
        return {"error": "invalid-firstname"}, 400
    if not re.match("^.+@.+.+$", email):
        return {"error": "invalid-email"}, 400
    elif app.security.datastore.find_user(email=email):
        return {"error": "duplicate email"}, 400
    if password != confirm:
        return {"error": "invalid-password"}, 400

    user = app.security.datastore.create_user(firstname=firstname,
                                              lastname=lastname,
                                              email=email,
                                              mobile=mobile,
                                              password=generate_password_hash(password))
    role = app.security.datastore.find_role("user")
    app.security.datastore.add_role_to_user(user, role)
    db.session.commit()
    return {"message": "Created user successfully"}, 201


@view.route("/signin", methods=["POST"])
def signin():
    email = request.json.get("email", "")
    password = request.json.get("password")

    user = app.security.datastore.find_user(email=email)
    if not user or not check_password_hash(user.password, password):
        return {"error": "user not found."}, 404

    login_user(user)
    token = user.get_auth_token()
    roles = [role.name for role in user.roles]
    return {"token": token, "roles": roles}


@view.route("/genre")
def get_genres():
    genres = Genre.query.all()
    result = []
    for genre in genres:
        result.append(genre.dict())

    return result


@view.route("/status")
def get_status():
    status = Status.query.all()
    result = []
    for stat in status:
        result.append(stat.dict())

    return result


@view.route("/category")
def get_category():
    category = Section.query.with_entities(Section.name).all()
    result = []

    for cat in category:
        result.append(cat[0])
    print("category Result:", result)
    print(result)
    return result


@view.route("/section/create", methods=["POST"])
@auth_required("token")
@roles_required("admin")
def create_section():
    name = request.form.get("name", None)
    description = request.form.get("description", None)
    section_genres = request.form.getlist("genre", type=int)
    date = request.form.get("date")
    cdate = datetime.strptime(date, '%Y-%m-%d')

    if not name:
        return {"error": "Invalid title"}, 400
    elif not description:
        return {"error": "Invalid description"}, 400

    genres = Genre.query.filter(Genre.id.in_(section_genres)).all()

    if len(section_genres) != len(genres):
        return {"error": "Invalid genres"}, 400

    section = Section(name=name, description=description, date=cdate)

    db.session.add(section)
    db.session.flush()

    for genre in genres:
        db.session.add(SectionGenre(section_id=section.id, genre_id=genre.id))

    db.session.commit()

    return {"message": "Created Section successfully"}, 201


@view.route("/section/search", methods=["POST"])
@auth_required("token")
def search_section():
    search = request.json.get("search", "")
    option = request.json.get("option")

    if option == "Name":
        sections = Section.query.filter(Section.name.like(f"%{search}%")).all()

    if option == "Description":
        sections = Section.query.filter(
            Section.description.like(f"%{search}%")).all()

    return [{"id": section.id,
             "name": section.name,
             "description": section.description,
             "date": section.date} for section in sections]


@view.route("/section/<int:section_id>", methods=["DELETE"])
@auth_required("token")
@roles_required("admin")
def delete_venue(section_id):
    section = db.session.query(Section).get(section_id)

    if not section:
        return {"error": "Section not Found"}, 404

    db.session.delete(section)
    db.session.commit()
    return {"message": "Deleted section successfully."}, 200


@view.route("/section/<int:section_id>/edit", methods=["POST"])
@auth_required("token")
@roles_required("admin")
def update_section(section_id):
    name = request.json.get("name", "")
    description = request.json.get("description")
    date = request.json.get("date")
    cdate = datetime.strptime(date, '%Y-%m-%d')
    if not name:
        return {"error": "Invalid name"}, 400
    if not description:
        return {"error": "Invalid description"}, 400
    if not date:
        return {"error": "Invalid date"}, 400

    section = db.session.query(Section).get(section_id)

    if not section:
        return {"error": "Section not found."}, 404

    section.name = name
    section.description = description
    section.date = cdate
    db.session.commit()
    return {"message": "Updated section successfully."}, 200


@view.route("/book/create", methods=["POST"])
@auth_required("token")
@roles_required("admin")
def create_book():
    title = request.form.get("title", None)
    description = request.form.get("description")
    date = request.form.get("date")

    author = request.form.get("author")
    sectionNames = request.form.get("sectionNames")
    status = request.form.get("bookStatus")
    print("book status__:", status)

    price = request.form.get("price")
    poster = request.files.get("poster")
    content = request.files["content"]

    cdate = datetime.strptime(date, '%Y-%m-%d')

    stat = Status.query.filter(Status.id == status).first()
    status = stat.status
    print("filter_Status", status)
    section = Section.query.filter(
        Section.name.like(f"%{sectionNames}%")).first()
    section_id = section.id

    if not title:
        return {"error": "Invalid title"}, 400
    # elif not description:
    #     return {"error": "Invalid description"}, 400

    book = Book(title=title,
                description=description, date=cdate,
                price=price, author=author, status=status,
                section_id=section_id
                )
    print("book added", book)
    print("book status:", book.status)
    db.session.add(book)
    db.session.flush()

    book.poster = f"{book.id}-{secure_filename(poster.filename)}"
    poster.save(os.path.join("static/uploads", book.poster))
    book.content = f"{book.id}-{secure_filename(content.filename)}"
    content.save(os.path.join("static/uploads/ebooks", book.content))

    db.session.commit()

    return {"message": "Created book successfully"}, 201


@view.route("/books")
@auth_required("token")
def get_books():
    search = request.args.get("search", None)

    option = request.args.get("option")

    temp_book = []
    if option == "Title":
        temp_book = Book.query.filter(Book.title.like(f"%{search}%")).all()
    if option == "Description":
        temp_book = Book.query.filter(
            Book.description.like(f"%{search}%")).all()
    if option == "Author":
        temp_book = Book.query.filter(
            Book.author.like(f"%{search}%")).all()
    books = []
    for book in temp_book:
        # pdf_base64 = base64.b64encode(book.content).decode('utf-8')
        formatted_date = book.date.isoformat()[:10]
        print("book_status", book.status)
        books.append({"id": book.id,
                      "title": book.title,
                      "content": book.content,
                      "description": book.description,
                      "date": formatted_date,
                      "price": book.price,
                      "author": book.author,
                      "poster": book.poster,
                      "status": book.status,
                      "section_id": book.section_id
                      })
    print("books", books)
    return books


@view.route("/getmybooks")
@auth_required("token")
def get_my_books():

    register = db.session.query(Register).filter_by(
        user_id=current_user.id).all()

    print("register", register)
    if not register:
        return {"error": "User Not having any books."}, 404
    my_books = []
    status = ''
    for eachbook in register:
        book = Book.query.filter_by(id=eachbook.book_id).first()
        status = book.status
        print("status for getting book", status)
        if (status == "Issued"):
            formatted_date = book.date.isoformat()[:10]
            my_books.append({"id": book.id,
                             "title": book.title,
                             "content": book.content,
                             "description": book.description,
                             "date": formatted_date,
                             "price": book.price,
                             "author": book.author,
                             "poster": book.poster,
                             "status": book.status,
                             "section_id": book.section_id
                             })
    print("my_books", my_books)
    return my_books


@view.route("/admin/book/<int:book_id>", methods=["DELETE"])
@auth_required("token")
@roles_required("admin")
def delete_book(book_id):

    book = db.session.query(Book).get(book_id)
    if not book:
        return {"error": "book not found!"}, 404
    db.session.delete(book)
    db.session.commit()
    return {"message": "Deleted book successfully."}


@view.route("/book/<int:book_id>/edit", methods=["POST"])
@auth_required("token")
@roles_required("admin")
def edit_book(book_id):

    title = request.form.get("title", None)
    description = request.form.get("description")
    date = request.form.get("date")
    author = request.form.get("author")
    sectionNames = request.form.get("sectionNames")
    status = request.form.get("bookStatus")
    price = request.form.get("price")
    poster = request.files.get("poster")
    content = request.files.get("content")

    print("content", content)
    print("poster", poster)

    section = Section.query.filter(
        Section.name.like(f"%{sectionNames}%")).first()
    section_id = section.id

    print("Section_id", section_id)

    if not title:
        return {"error": "Invalid title"}, 400

    book = db.session.query(Book).get(book_id)
    if not book:
        return {"error": "Book not found."}, 404

    cdate = datetime.strptime(date, '%Y-%m-%d')
    book.title = title
    book.description = description
    book.date = cdate
    book.author = author
    book.status = status
    print("book section_id", book.section_id)
    book.section_id = section_id
    book.price = price

    if poster == None:
        poster = book.poster
        print("book.poster in table", book.poster)
    else:
        book.poster = f"{book.id}-{secure_filename(poster.filename)}"
        poster.save(os.path.join("static/uploads", book.poster))
    if content == None:
        content = book.poster
    else:
        book.content = f"{book.id}-{secure_filename(content.filename)}"
        content.save(os.path.join("static/uploads/ebooks", book.content))

    db.session.commit()

    return {"message": "Updated Book successfully"}, 200


@view.route("/book/<int:book_id>/allocate", methods=["POST"])
@auth_required("token")
def allocate_book(book_id):
    title = request.form.get("title")
    username = request.form.get("username")
    bookStatus = request.form.get("bookStatus")
    request_date = request.form.get("request_date")
    issue_date = request.form.get("issue_date")
    request_date = datetime.strptime(request_date, '%Y-%m-%d')
    issue_date = datetime.strptime(issue_date, '%Y-%m-%d')
    return_date = issue_date + timedelta(days=15)

    users = User.query.filter(User.firstname.like(f"%{username}%")).first()

    if not users:
        return {"message": "User not registered, Enter correct name or register."}, 404
    else:
        user_id = users.id
        username = users.firstname
    status = ''
    if bookStatus == "Available":
        status = "Issued"
    elif bookStatus == "Requested":
        status = "Issued"
    elif bookStatus == "Issued":
        status = "Issued"
    elif status == "Revoked":
        status = "Issued"
    else:
        return {"message": "Can't allocate book which is not available status"}, 404
    print("status before allocation", status)
    register = Register.query.filter_by(
        book_id=book_id, user_id=user_id).first()
    print("register in allocation", register)
    book = Book.query.filter(Book.id == book_id).first()
    if not register:
        print("if not register")
        register = Register(username=username,
                            book_name=title,
                            request_status=status,
                            user_id=user_id,
                            book_id=book_id,
                            date_issued=issue_date,
                            requsted_date=request_date,
                            return_date=return_date)
        print("after register", register)
        db.session.add(register)
        db.session.flush()
        book.status = bookStatus
        db.session.commit()
        return {"message": "Allocated Book successfully"}, 200

    else:
        print("else register")
        print("register.request_status", register.request_status)
        if register.request_status != "Not Available":
            stat = register.request_status
            print("inside status for register ", stat)
        else:
            return {"error": "Book already allocated"}, 404
        if stat == "Issued":
            print("book.status", book.status)
            print("book_status", status)
            book.status = stat
            register.request_status = stat
            db.session.commit()
            return {"error": "Book already allocated"}, 404
        else:

            book.status = status
            register.request_status = status
            db.session.commit()
            return {"message": "Book allocated successfully"}, 200


@view.route("/book/<int:book_id>/deallocate", methods=["POST"])
@auth_required("token")
@roles_required("admin")
def deallocate_book(book_id):
    title = request.form.get("title")
    bookStatus = request.form.get("bookStatus")
    print("bookStatus", bookStatus)
    book = Book.query.filter(Book.id == book_id).first()
    book.status = bookStatus
    print("book", book.status)

    register = Register.query.filter_by(book_id=book_id).filter(
        Register.request_status == bookStatus).first()

    print("registers", register)

    if not register:
        return {"message": " Book already deallocated"}, 200
    else:
        register.request_status = bookStatus
        print("register.request_status", register.request_status)
        register.return_date = datetime.now()
        print("inside deallocate")
        print("register.request_status", register.request_status)
        db.session.commit()
        return {"message": "deallocated Book successfully"}, 200


@view.route("/book/<int:book_id>/request", methods=["POST"])
@auth_required("token")
def request_book(book_id):

    title = request.form.get("title", None)
    description = request.form.get("description")
    requestdate = request.form.get("requestdate")
    author = request.form.get("author")
    status = request.form.get("bookStatus")
    price = request.form.get("price")
    user_id = current_user.id

    if not title:
        return {"error": "Invalid title"}, 400

    book = db.session.query(Book).get(book_id)

    if not book:
        return {"error": "Book not found."}, 404
    cdate = datetime.strptime(requestdate, '%Y-%m-%d')
    stat = book.status
    registers = db.session.query(Register).filter_by(
        user_id=current_user.id).all()
    count = 0

    for register in registers:
        regstat = register.request_status

        if (regstat == "Issued") or (regstat == "Requested"):
            count += 1

    if (status == 'Available') and (count <= 5):
        book.status = "Requested"
        register.request_status = "Requested"
        db.session.commit()
        return {"message": "Requested Book successfully"}, 200
    else:
        return {"error": "Book not correct status and 5 more books"}, 404


@view.route("/book/return/<int:book_id>", methods=["POST"])
@auth_required("token")
def return_book(book_id):

    book = db.session.query(Book).get(book_id)
    if not book:
        return {"error": "book not found!"}, 404

    status = book.status

    register = db.session.query(Register).filter_by(
        book_id=book_id, user_id=current_user.id).first()

    register.request_status = "Returned"
    book.status = "Returned"
    db.session.commit()
    return {"message": "Returned book successfully."}


@view.route("/user/feedback/<int:book_id>", methods=["POST"])
@auth_required("token")
def feed_back(book_id):
    textInput = request.json.get("textInput", "")
    print("textInput", textInput)
    print("book_id", book_id)

    feedback = Feedback(user_id=current_user.id,
                        book_id=book_id, review=textInput)
    db.session.add(feedback)
    db.session.flush()
    db.session.commit()
    return {"message": "Feedback received for the book."}, 200


@view.route("/admin/section/statistics")
@auth_required("token")
@roles_required("admin")
def section_statistics():
    result = {"sections": [], "total": []}
    for section in Section.query.all():
        count = 0
        for book in section.books:
            count += 1

        result["sections"].append(section.name)
        result["total"].append(count)
    return result


@view.route("/admin/book/statistics")
@auth_required("token")
@roles_required("admin")
def book_statistics():
    result = {"author": [], "price": []}
    for author, price in Book.query.with_entities(Book.author, Book.price).all():
        if author in result["author"]:
            index = result["author"].index(author)
            result["price"][index] += price
        else:
            result["author"].append(author)
            result["price"].append(price)
    return result


@view.route("/export")
@auth_required("token")
@roles_required("admin")
def export():
    task = request.args.get("task")
    if not task:
        result = export_pdf.delay()
        return {"id": result.id}
    else:
        result = AsyncResult(task)
        print("result.status", result.status)
        return {"status": result.status}


@view.route("/download")
def download_pdf():
    task_id = request.args.get("task")
    if not task_id:
        return "Task ID is missing", 400
    result = AsyncResult(task_id)

    # Check if the task is ready
    if result.ready():
        if result.successful():

            pdf_content = result.result
            file = BytesIO(pdf_content)
            file.seek(0)
            # Return the PDF file for download
            return send_file(file, mimetype="application/pdf",
                             as_attachment=True, download_name="export.pdf")
        else:
            return "Task failed to generate PDF", 500
    else:
        return "Task is still pending", 202
