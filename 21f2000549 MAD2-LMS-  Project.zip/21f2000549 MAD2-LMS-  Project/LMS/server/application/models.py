from flask_sqlalchemy import SQLAlchemy
from flask_security import UserMixin, RoleMixin
from datetime import datetime


db = SQLAlchemy()


class User(db.Model, UserMixin):
    __tablename__ = "user"

    id = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    firstname = db.Column(db.String(), nullable=False)
    lastname = db.Column(db.String())
    email = db.Column(db.String(), nullable=False, unique=True)
    mobile = db.Column(db.String(10))
    password = db.Column(db.String(), nullable=False)
    active = db.Column(db.Boolean())
    authenticated = db.Column(db.Boolean())
    fs_uniquifier = db.Column(db.String(64), unique=True, nullable=False)

    roles = db.relationship("Role",
                            secondary="user_roles",
                            backref=db.backref("backref", lazy=True))


class Role(db.Model, RoleMixin):
    __tablename__ = "role"

    id = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    name = db.Column(db.String(), nullable=False)


class UserRoles(db.Model):
    __tablename__ = "user_roles"

    id = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer(), db.ForeignKey("user.id"))
    role_id = db.Column(db.Integer(), db.ForeignKey("role.id"))


class Section(db.Model):
    __tablename__ = "section"

    id = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    name = db.Column(db.String(50), unique=True, nullable=False)
    description = db.Column(db.String(200))
    date = db.Column(db.DateTime, default=datetime.utcnow)
    genres = db.relationship("Genre", secondary="section_genre")
    books = db.relationship('Book', backref='section', lazy=True)

    def dict(self):
        genres = []
        for genre in self.genres:
            genres.append(genre.dict())

        return {
            "id": self.id,
            "name": self.title,
            "description": self.description,
            "date": self.date,
            "genres": genres
        }

    def section_count(self):
        count = 0
        for stat in self.title:
            count += 1
        return count


class Genre(db.Model):
    __tablename__ = "genre"

    id = db.Column(db.Integer(), primary_key=True)
    type = db.Column(db.String(), nullable=False)

    def dict(self):
        return {"id": self.id, "type": self.type}


class SectionGenre(db.Model):
    __tablename__ = "section_genre"

    id = db.Column(db.Integer(), primary_key=True)
    section_id = db.Column(db.Integer(), db.ForeignKey("section.id"))
    genre_id = db.Column(db.Integer(), db.ForeignKey("genre.id"))


class Book(db.Model):
    __tablename__ = "book"

    id = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    title = db.Column(db.String(100), nullable=False)
    content = db.Column(db.String())
    description = db.Column(db.String(200))
    date = db.Column(db.DateTime, default=datetime.utcnow)
    price = db.Column(db.Float, nullable=False)
    author = db.Column(db.String(50), nullable=False)
    # Available,Issued, Returned, Not Available
    poster = db.Column(db.String())
    status = db.Column(db.String(50), default="Available")
    section_id = db.Column(db.Integer(), db.ForeignKey(
        'section.id'), nullable=False)
    feedbacks = db.relationship('Feedback', backref='feedback', lazy=True)


class Status(db.Model):
    __tablename__ = "status"

    id = db.Column(db.Integer(), primary_key=True)
    status = db.Column(db.String(), nullable=False)

    def dict(self):
        return {"id": self.id, "status": self.status}


class Register(db.Model):
    __tablename__ = "register"

    id = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    username = db.Column(db.String(50), nullable=False)
    book_name = db.Column(db.String(100), nullable=False)
    request_status = db.Column(db.String(100), nullable=False)
    user_id = db.Column(db.Integer(), db.ForeignKey('user.id'), nullable=False)
    book_id = db.Column(db.Integer(), nullable=False)
    date_issued = db.Column(db.DateTime)
    requsted_date = db.Column(db.DateTime, default=datetime.utcnow)
    return_date = db.Column(db.DateTime)


class Feedback(db.Model):
    __tablename__ = "feedback"

    id = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer(), db.ForeignKey("user.id"), nullable=False)
    book_id = db.Column(db.Integer(), db.ForeignKey("book.id"), nullable=False)
    review = db.Column(db.String(200))
