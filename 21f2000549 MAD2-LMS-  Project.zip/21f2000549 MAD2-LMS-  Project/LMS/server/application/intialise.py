from flask import current_app as app
from werkzeug.security import generate_password_hash
from flask import Flask
from celery import Celery, Task


from .models import db, Genre, Status

GENRES = ['Action', 'Adventure', 'Animation', 'Biography',
          'Comedy', 'Crime', 'Documentary', 'Drama', 'Family',
          'Fantasy', 'Film-Noir', 'History', 'Horror', 'Music',
          'Musical', 'Mystery', 'Romance', 'Sci-Fi', 'Short',
          'Sport', 'Thriller', 'War', 'Western']

STATUS = ['Not Available', 'Available',
          'Issued', 'Returned', 'Revoked', 'Requested']


def main():

    if not app.security.datastore.find_role("admin"):
        admin = app.security.datastore.create_role(name="admin")
        app.security.datastore.create_role(name="user")
        db.session.flush()
        user = app.security.datastore.create_user(firstname="Ramesh",
                                                  lastname="Chandran",
                                                  email="Ramesh.Chandran@gmail.com",
                                                  mobile="9626075846",
                                                  password=generate_password_hash("ramesh"))
        app.security.datastore.add_role_to_user(user, admin)
        add_genres()
        add_status()
        db.session.commit()


def add_genres():

    for genre in GENRES:
        db.session.add(Genre(type=genre))


def add_status():
    for stat in STATUS:
        db.session.add(Status(status=stat))

def celery_init_app(app: Flask) -> Celery:
    class FlaskTask(Task):
        def __call__(self, *args: object, **kwargs: object) -> object:
            with app.app_context():
                return self.run(*args, **kwargs)

    celery_app = Celery(app.name)
    celery_app.config_from_object(app.config["CELERY"])
    celery_app.Task = FlaskTask
    celery_app.set_default()
    app.extensions["celery"] = celery_app
    return celery_app
