from celery import shared_task
from jinja2 import Template

from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from smtplib import SMTP
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.encoders import encode_base64
from io import BytesIO
import csv
from io import StringIO
from .models import db, User, Register, Book


@shared_task
def daily_reminder():
    user_ids = []
    for register in Register.query.all():
        user_ids.append(register.user_id)

    server = SMTP(host="0.0.0.0", port=1025)
    for user in User.query.filter(User.id.not_in(user_ids)).all():
        message = MIMEMultipart()
        message["From"] = "Ramesh.Chandran@example.com"
        message["To"] = user.email
        message["Subject"] = "Missed login! Vist soon, You are missing out new arrivals."

        with open("static/email.jpg", "rb") as file:
            image = MIMEBase("application", "octet-stream")
            image.set_payload(file.read())
            image.add_header("content-disposition",
                             "attachment; filename=email.jpg")
            encode_base64(image)

        message.attach(image)

        with open("static/image.pdf", "rb") as file:
            image = MIMEBase("application", "octet-stream")
            image.set_payload(file.read())
            image.add_header("content-disposition",
                             "attachment; filename=image.pdf")
            encode_base64(image)

        message.attach(image)

        server.sendmail("Ramesh.Chandran@gmail.com",
                        user.email,
                        message.as_string())
    return True


# @shared_task
# def export_csv():
#     content = StringIO()
#     writer = csv.writer(content)
#     writer.writerow(["Book Name", "Status not returned", "Total Books"])

#     for register in Register.query.all():
#         row = [register.book_name, register.request_status]
#         count = 0
#         if register.request_status == "Issued":
#             count += 1
#         row.append(count)
#         writer.writerow(row)

#     content.seek(0)
#     return content.read()

@shared_task
def export_pdf():
    buffer = BytesIO()
    pdf_canvas = canvas.Canvas(buffer, pagesize=letter)

    # Set up the PDF content
    pdf_canvas.drawString(100, 750, "Book Name")
    pdf_canvas.drawString(250, 750, "Status not returned")
    pdf_canvas.drawString(400, 750, "Total Books")

    y_position = 730  # Initial Y position for the first row
    for register in Register.query.all():
        y_position -= 20  # Move to the next row
        pdf_canvas.drawString(100, y_position, register.book_name)
        pdf_canvas.drawString(250, y_position, register.request_status)
        count = 0
        if register.request_status == "Issued":
            count += 1
        pdf_canvas.drawString(400, y_position, str(count))

    pdf_canvas.save()
    buffer.seek(0)

    return buffer.getvalue()


@shared_task
def report():
    with open("templates/report.html") as file:
        template = Template(file.read())

    server = SMTP(host="0.0.0.0",
                  port=1025)

    for user in User.query.all():
        registers = Register.query.filter_by(user_id=user.id)
        content = template.render(user=user, register=registers)

        message = MIMEMultipart()
        message["From"] = "Ramesh.Chandran@gmail.com"
        message["To"] = user.email
        message["Subject"] = "Monthly Report."
        html = MIMEText(content, "html")
        message.attach(html)

        server.sendmail("Ramesh.Chandran@gmail.com",
                        user.email,
                        message.as_string())
