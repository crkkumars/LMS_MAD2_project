<script setup>
import DangerAlert from "@/components/DangerAlert.vue";
import SuccessAlert from "@/components/SuccessAlert.vue";
import store from "@/store";
</script>
<template>
    <SuccessAlert :message="deleteSuccess"/>
    <DangerAlert :message="error['deleteFaliure']"/>
    <form @submit="getBooks">
        <div class="row" style="margin: 20px;">           
            <div class="col">
                <input type="submit" style="width: 15%;" class="btn btn-success" value="getdetails">
            </div>
        </div>
        <div class="card" v-for="book in my_books" style="margin: 15px;">
            <div class="card-body" style="display: flex; align-items: center;">
                <div class="row" style="width: 100%; display: flex; align-items: center;">
                    <div class="col" style="max-width: max-content;">
                        <img :src="posterUrl(book.poster)" class="img-thumbnail" 
                            style="height: 150px; width: 120px;">
                    </div>
                   
                    <div class="col" style="min-width: 60%;">
                        <div>
                           
                            <h5 class="card-title">{{ book.title }}</h5>
                            <h6 class="card-description">{{ book.description }}</h6>
                            <h6 class="card-author">{{ book.author }}</h6>  
                            <h6 class="card-author">{{ book.status }}</h6>   

                        </div>
                    </div>
                    <div class="col">
                        <input type=button class="btn btn-danger" style="margin-left:15px"
                                        @click="returnBook(book.id)" value="Return">
                        <input type=button class="btn btn-warning" style="margin-left:15px"
                                        @click="downloadPdf(book.content)" value="Download">
                        
                    </div>
                </div>
            </div>
            <div class="accordion" id="accordionExample" style="margin: 20px;">
                <div class="accordion-item">
                    <h2 class="accordion-header">
                    <button class="accordion-button collapsed" type="button"
                        data-bs-toggle="collapse" :data-bs-target="'#collapseBook'+book.id"
                        aria-expanded="true" aria-controls="collapseOne">
                        Feed back
                    </button>
                    </h2>
                <div :id="'collapseBook'+book.id" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                    <div class="accordion-body" style="display: flex; flex-wrap: wrap; ">
                        <div  class="accordion-content">
                            <input type="textarea" v-model="textInput" placeholder="Enter text"
                                style="width: 800px">
                            <button  class="btn btn-success" style="margin-left:15px" @click="getFeedback(book.id)">Submit</button>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </form>
</template>
<script>
    export default{
        data(){
            return{ 
                book:[],                                     
                deleteSuccess: null,               
                error: {                    
                deleteFaliure: null,
              }
            }
        },
        created(){            
            store.dispatch("getMyBooks");
        },
        methods: {
            getBooks(event){
                event.preventDefault();
                store.dispatch("getMyBooks");                                         
            },           
            posterUrl(value){
                return `${store.getters.BASEURL}/static/uploads/${value}`;
            },
            downloadPdf(value){
                const pdfUrl = `${store.getters.BASEURL}/static/uploads/ebooks/${value}`;
                const link = document.createElement('a');
                link.href = pdfUrl;
                link.target = '_blank'; 
                link.setAttribute('download', `${value}.pdf`);
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            },
            returnBook(book_id){
                fetch(store.getters.BASEURL+"/book/return/"+book_id, {
                    method: "POST",
                    headers:{
                        "Content-Type": "application/json",
                        "Authentication-Token": store.getters.getToken
                    }
                }).then(response =>{
                    if(response.status == 200){
                        this.deleteSuccess = "Return Book successfully"
                        store.dispatch("getMyBooks");                   
                    }
                    else if(response.status == 404){
                        this.error["deleteFaliure"] = "Book not Returned."
                    }
                })
            },
            getFeedback(book_id){
                fetch(store.getters.BASEURL+"/user/feedback/"+book_id, {
                    method: "POST",
                    headers:{
                        "Content-Type": "application/json",
                        "Authentication-Token": store.getters.getToken
                    },
                    body:JSON.stringify({textInput: this.textInput})                                     
                }).then(response =>{
                    if(response.status == 200){
                        this.deleteSuccess = "Feedback received for the book.";
                      
                    }
                    else if(response.status == 404)
                        this.error["deleteFaliure"] = "Feedback Not updated."
                })
            }
        },
        computed: {
            my_books(){
                return store.getters.getMyBooks;
            }
        },     
    }
</script> 