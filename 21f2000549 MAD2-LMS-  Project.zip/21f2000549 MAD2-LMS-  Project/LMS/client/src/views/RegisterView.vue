<script setup>
    import CommonNavbar from "@/components/CommonNavbar.vue";
import store from "@/store";
</script>
<template>
    <CommonNavbar />
    <div class="alert alert-success alert-dismissible fade show" role="alert" v-if="success">
        Created user successfully!
        <button type="button" @click="success=false"class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <div class="container-fluid section-container">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title" align="center">Register</h4>
                <form @submit="register">
                    <div class="row">
                        <div class="col">
                            <input type="text" class="form-control" placeholder="First name" 
                                aria-label="First name"v-model="firstname">
                            <div class="invalid-feedback" 
                                :style="{display: (error['firstname'])? 'block': 'none'}">
                                {{ error["firstname"] }}
                            </div>
                        </div>
                        <div class="col">
                            <input type="text" class="form-control" placeholder="Last name" 
                                aria-label="Last name" v-model="lastname">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <input type="email" class="form-control" placeholder="Email" 
                            aria-label="Email" v-model="email">
                            <div class="invalid-feedback" 
                                :style="{display: (error['email'])? 'block': 'none'}">
                                {{ error["email" ]}}
                            </div>
                        </div>
                        <div class="col">
                            <input type="text" class="form-control" placeholder="Mobile" 
                                aria-label="Mobile" v-model="mobile">
                        </div>                        
                    </div>
                    <div class="row">
                        <div class="col">
                            <input type="password" class="form-control" placeholder="Password" 
                                aria-label="Password" v-model="password">
                            <div class="invalid-feedback" 
                                :style="{display: (error['password'])? 'block': 'none'}">
                                {{ error["password" ]}}
                            </div>
                        </div>
                        <div class="col">
                            <input type="password" class="form-control" placeholder="Confirm Password"
                                aria-label="Confirm Password" v-model="confirm">
                        </div>                        
                    </div>
                    <div class="row">    
                        <div class="col">                          
                        </div>                    
                        <div class="col">
                            <input type="submit" class="btn btn-primary" placeholder="Submit" 
                            aria-label="Submit">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        data() {
            return {
                firstname: null,
                lastname: null,
                password: null,
                confirm: null,
                email: "",
                mobile:null,
                success: false,
                error: {
                    firstname: null,
                    lastname: null,                    
                    password: null,
                    confirm: null,
                    email: null,
                    mobile:null,
                }
            }
        },
        methods: {
            validate() {
                let error = false;
                this.error = {
                    firstname: null,
                    lastname: null,
                    password: null,
                    confirm: null,
                    email: null,
                    mobile:null,
                }
                if(!this.firstname || this.firstname.length < 2){
                    error = true;
                    this.error["firstname"] = "Required filed"
                }
                if(this.password != this.confirm){
                    error = true;
                    this.error["password"] = "Password doesn't match."
                }
                if(!this.email.match(/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/)){
                    error = true;
                    this.error["email"] = "Invalid email."
                }
                return error;
            },
            register(event) {
                event.preventDefault();
                if(!this.validate())
                    fetch(store.getters.BASEURL+"/register", {
                                        method: "POST",
                                        headers:{
                                            "Content-Type": "application/json"
                                        },
                                        body:JSON.stringify({
                                            firstname: this.firstname,
                                            lastname: this.lastname,
                                            email: this.email,
                                            mobile:this.mobile,
                                            password: this.password,
                                            confirm: this.confirm
                                        })
                                    }).then(response =>{ 
                                        return [response.json(), response.status];
                                    }).then(data =>{
                                        if(data[1] == 400){
                                            let error = data[0]["error"]
                                            if(error == "invalid-firstname")
                                                this.error["firstname"] = "Invalid firstname"
                                            else if(error == "invalid-email")
                                                this.error["email"] = "Invalid email."
                                            else if(error == "duplicate email")
                                                this.error["email"] = "Email already in use."
                                            else if(error == "invalid-password")
                                                this.error["password"] = "Invalid password."
                                        }
                                        else if(data[1] == 201){
                                            this.success = true;
                                        }
                                    })
            }
        }
    }
</script>
<style scoped>
    .section-container {
        height: 90vh;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .row {
        margin-top: 20px;
    }

    .btn {
        width: 100%;
    }
</style>
