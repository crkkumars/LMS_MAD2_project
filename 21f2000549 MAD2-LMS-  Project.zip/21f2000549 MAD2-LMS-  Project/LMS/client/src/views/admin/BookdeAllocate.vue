<script setup>
    import DangerAlert from "@/components/DangerAlert.vue";
import SuccessAlert from "@/components/SuccessAlert.vue";
import store from "@/store";
</script>
<template>
    <SuccessAlert :message="message"/>
    <DangerAlert :message="danger"/>
    
    <form @submit="allocateBook">
        <div class="row" style="padding: 20px 20px 20px ;">
            <div class="col">
                <label for="Title" class="form-label"> Book Title</label>
                <input type="text" class="form-control" id="Title" v-model="title"
                    placeholder="Book Title">
            </div>
            <div class="col">
                <label for="status" class="form-label">Status</label>
                    <select class="form-select"   v-model="bookStatus">
                     <option v-for="stat in status" :value="stat.status" >
                        {{ stat["status"] }}</option>
                    </select>
            </div>  
        </div>
        <div class="row" style="padding: 20px 20px 20px ;">
            
            <div class="col" style="display: flex; justify-content: right;">
                <input type="submit" class="btn btn-primary" value="Deallocate" style="width: 25%;">
            </div>          
        </div>            
    </form>
</template>
<script>
    export default{
        props: ["id"],
        data(){
            return {
                title: this.$route.query["title"],
                bookStatus: this.$route.query["status"],                         
                message: null,
                danger: null
               
            }
        },
        created(){          
            store.dispatch("getStatus")                       
        },
        methods:{
                      
            validate(){
                let error = false;
                this.error = {
                    title: null,
                }              
                
                return error;
            },
            allocateBook(event){
                event.preventDefault();
                if(!this.validate()){
                    let form = new FormData();
                    form.append("title", this.title);                   
                    form.append("bookStatus", this.bookStatus);                   
                    fetch(store.getters.BASEURL+"/book/"+this.id+"/deallocate", {
                        method: "POST",
                        headers:{
                            "Authentication-Token": store.getters.getToken
                        },
                        body:form
                    }).then(response =>{
                        return response.json()
                    }).then(data =>{
                        
                        if(Object.keys(data).includes("error")){
                            let error = data["error"];
                            if(error == "Invalid title"){
                                this.error["title"] = "Invalid title."
                            }                                                
                        }
                        else{
                            this.message = "Deallocated Book Successfully."
                        }
                    })
                }

            }
        },
        computed:{          
            
            status(){
                return store.getters.getStatus;
            },
                       
        }
    }
</script>
<style scoped>
    .allocate-book-section{
        margin: 20px;
    }
</style>
