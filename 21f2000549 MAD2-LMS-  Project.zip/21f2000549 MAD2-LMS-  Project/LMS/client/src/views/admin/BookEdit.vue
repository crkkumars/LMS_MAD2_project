<script setup>
import InputError from "@/components/InputError.vue";
import SuccessAlert from "@/components/SuccessAlert.vue";
import store from "@/store";
</script>
<template>
    <SuccessAlert :message="message"/>
    <div class="row create-book-section">
        <div class="row">
            <div class="col" style="display: flex; align-items: center;">
                <div class="card" >
                    <img :src="image" v-if="image" style="height: 90% !important;" class="card-img-top" alt="...">
                </div>
            </div>
            <div class="col" style="min-width: 75%;">
                <div class="card create-Book-section">
                    <div class="card-body">
                        <form @submit="createBook">
                            <div class="row">                                
                                <div class="col">
                                    <div class="mb-3">
                                        <label for="BookTitleInput" class="form-label"> Book Title</label>
                                        <input type="text" class="form-control" id="BookTitleInput" v-model="title"
                                            placeholder="Book Title">
                                        <InputError :value="error['title']"/>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="mb-3">
                                        <label for=" BookDescription" class="form-label"> Book Description</label>
                                        <input type="text" class="form-control" id="BookDescription" v-model="description"
                                            placeholder="Book Description">
                                            <!-- <InputError :value="error['description']"/> -->
                                    </div>
                                </div>
                            </div>
                            <div class="row" style="display: flex; align-items: center;">
                                <div class="col">
                                    <div class="mb-3">
                                        <label for="BookCreationDate" class="form-label">Book Added Date</label>
                                        <input type="date" class="form-control" id="BookCreationDate" v-model="date"
                                        placeholder="Book Creation Date">
                                        <!-- <InputError :value="error['date']"/> -->
                                    </div>   
                                </div>
                                <div class="col">
                                    <div class="mb-3">                                        
                                      <label for="BookAuthor" class="form-label">Author</label>
                                       <input type="text" class="form-control" id="BookAuthor" v-model="author"
                                        placeholder="Author">
                                      <!-- <InputError :value="error['author']"/> -->
                                    </div>
                                </div>                                  
                            </div> 
                            <div class="row" style="display: flex; align-items: center;">
                                <div class="col">
                                    <div class="mb-3">                                                                            
                                        <label for="Section" class="form-label">Section Name</label>
                                        <select class="form-select" v-model="sectionNames">
                                            <option v-for="cat in category"  :selected="sectionNames.includes(cat)">
                                                {{ cat }}</option>                                            
                                        </select>                                        
                                    </div>      
                                </div>                                  
                                
                                <div class="col">
                                    <div class="mb-3">                                                                            
                                        <label for="Section" class="form-label">Status</label>
                                        <select class="form-select"   v-model="bookStatus">
                                            <option v-for="stat in status" :value="stat.status" :selected="bookStatus.includes(stat.status)">
                                            {{ stat["status"] }}</option>
                                        </select>
                                    </div>      
                                </div>   
                                <div class="col">
                                    <div class="mb-3">
                                      <label for="Price" class="form-label">Price</label>
                                       <input type="number" min="0.00" max="10000.00" class="form-control" id="price" v-model="price"
                                        placeholder="price">
                                      <!-- <InputError :value="error['price']"/> -->
                                    </div>
                                </div>                      
                            </div>                
                            <div class="row" style="display: flex; align-items: center;">
                                <div class="col">
                                    <div class="mb-3">
                                        <label for="formFile" class="form-label">Book Poster</label>
                                        <input class="form-control" @change="getPoster" type="file" id="formFile">
                                    </div>
                                </div>
                                <div class="col">
                                    <label for="formFile" class="form-label">Content</label>
                                    <div class="mb-3">                                        
                                        <input type="file" @change="onFileChange">
                                       
                                    </div>
                                </div>                    
                            </div>                                  
                            <div class="mb-3" style="display: flex; justify-content: center;">
                                <input type="submit" class="btn btn-primary" value="Update" style="width: 25%;">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default{
        props: ["id"],
        data(){
            return {
                title: this.$route.query["title"],
                description: this.$route.query["description"],
                date: this.$route.query["date"],
                author: this.$route.query["author"],               
                bookStatus: this.$route.query["status"],
                sectionNames : [],
                price: this.$route.query["price"],
                poster: this.$route.query["poster"],
                content:this.getContent(),              
                image: this.getImage(),
                error: {
                    title: null,
                    description: null,  

                },
                message: null
            }
        },
        created(){
            store.dispatch("getGenres")
            store.dispatch("getStatus")
            store.dispatch("getCategory")
                       
        },
        methods:{
            getImage(){
                if (this.$route.query["poster"])
                    return store.getters.BASEURL+"/static/uploads/"+this.$route.query["poster"]
                else
                    return null;
            },
            getPoster(event){
                this.poster = event.target.files[0];
                this.readImage();
            },
            readImage(){
                const reader = new FileReader();
                reader.addEventListener('load', (event) => {
                    this.image = event.target.result;
                });
                reader.readAsDataURL(this.poster);
            },
            getContent(){
                if (this.$route.query["content"])
                return store.getters.BASEURL+"/static/uploads/ebooks"+this.$route.query["content"]
                else
                    return null;
            },

            onFileChange(event) {
                this.content = event.target.files[0];                         
            },            
            validate(){
                let error = false;
               
                if(!this.title){
                    error = true;
                    this.error["title"] = "Invalid title."
                }
                
                return error;
            },
            createBook(event){
                event.preventDefault();
                if(!this.validate()){
                    let form = new FormData();
                    form.append("title", this.title);
                    form.append("description", this.description);
                    form.append("date", this.date);
                    form.append("author", this.author);
                    form.append("sectionNames", this.sectionNames);
                    form.append("bookStatus", this.bookStatus);
                    form.append("price", this.price);
                    form.append("poster", this.poster);
                    form.append("content", this.content);

                    fetch(store.getters.BASEURL+"/book/"+this.id+"/edit", {
                        method: "POST",
                        headers:{
                            "Authentication-Token": store.getters.getToken
                        },
                        body:form
                    }).then(response =>{
                        return response.json()
                    }).then(data =>{
                        if(Object.keys(data).includes("error")){
                            let error = data["error"];
                            if(error == "Invalid title"){
                                this.error["name"] = "Invalid title."
                            }  
                            console.log("data",data)                                            
                        }
                        else{
                            this.message = "Updated Book Successfully."
                            }
                        })
                }

            }
        },
        computed:{
            genres(){
                return store.getters.getGenres;
            },
            status(){
                return store.getters.getStatus;
            },
            category(){
                return store.getters.getCategory;
            }
           
        }
    }
</script>
<style scoped>
    .create-book-section{
        margin: 20px;
    }
</style>
