<script setup>
import DangerAlert from "@/components/DangerAlert.vue";
import InputError from "@/components/InputError.vue";
import SuccessAlert from "@/components/SuccessAlert.vue";
import store from "@/store";
</script>
<template>
    <SuccessAlert :message="deleteSuccess"/>
    <DangerAlert :message="error['deleteFaliure']"/>
    <form @submit="searchBooks">
        <div class="row" style="margin: 20px;">
            <div class="col" style="min-width: 40%;">
                <input type="text" class="form-control" placeholder="Search" v-model="search" aria-label="Search">
                <InputError :value="error['search']"/>
            </div>            
            <div class="col" style="min-width: 20%;">
                <select class="form-select" aria-label="Filter" v-model="option">
                    <option selected>Title</option>
                    <option>Description</option>
                    <option>Author</option>                                                
                </select>           
                <InputError :value="error['search']"/>
            </div>
            <div class="col">
                <input type="submit" style="width: 100%;" class="btn btn-success" value="Search">
            </div>
        </div>
        <div class="card" v-for="book in books" style="margin: 15px;">
            <div class="card-body" style="display: flex; align-items: center;">
                <div class="row" style="width: 100%; display: flex; align-items: center;">
                    <div class="col" style="max-width: max-content;">
                        <img :src="posterUrl(book.poster)" class="img-thumbnail" 
                            style="height: 150px; width: 120px;">
                    </div>
                   
                    <div class="col" style="min-width: 60%;">
                        <div>
                           
                            <h5 class="card-title">{{ book.title }}</h5>
                            <h6 class="card-description">{{ book.description }}</h6>
                            <h6 class="card-author">{{ book.author }}</h6>  
                            <h6 class="card-author">{{ book.status }}</h6>   

                        </div>
                    </div>
                    <div class="col">
                        <router-link class="btn btn-warning" 
                            :to="{name: 'book-edit', params: {id: book.id}, query:{title: book.title, 
                                                    content:book.content,
                                                    description: book.description,
                                                    date: book.date,
                                                    price: book.price,
                                                    author: book.author,
                                                    poster:book.poster,
                                                    status: book.status }}">
                            Edit
                        </router-link>
                        <router-link class="btn btn-success" style="margin-left:15px"
                            :to="{name: 'book-allocate', params: {id: book.id},
                                    query:{title: book.title,
                                        content:book.content,
                                        description: book.description,
                                        date: book.date,
                                        price: book.price,
                                        author: book.author,
                                        poster:book.poster,
                                        status: book.status }}"> 
                            Allocate                                      
                        </router-link>
                        <router-link class="btn btn-success" style="margin-left:15px"
                            :to="{name: 'book-deallocate', params: {id: book.id},
                                        query:{title: book.title,                                        
                                        status: book.status }}">
                                Deallocate
                        </router-link>
                        <input type=button class="btn btn-danger" style="margin-left:15px" @click="deleteBook(book.id)" value="Delete">
                    </div>
                </div>
            </div>
        </div>
    </form>
</template>
<script>
    export default{
        data(){
            return{
                search: null,
                option: "Title",              
                deleteSuccess: null,
                // books: [],
                pdfUrls: null,
                error: {
                    search: null,
                    deleteFaliure: null,
                }
            }
        },
        created(){            
            store.dispatch("getBooks", {search: this.search, 
                                        option: this.option});
        },
        methods: {
            searchBooks(event){
                event.preventDefault();
                store.dispatch("getBooks",{search: this.search,
                                         option: this.option});
            },           
            posterUrl(value){
                return `${store.getters.BASEURL}/static/uploads/${value}`
            },   
            deleteBook(book_id){
                fetch(store.getters.BASEURL+"/admin/book/"+book_id, {
                    method: "DELETE",
                    headers:{
                        "Content-Type": "application/json",
                        "Authentication-Token": store.getters.getToken
                    }
                }).then(response =>{
                    if(response.status == 200){
                        this.deleteSuccess = "Deleted Book successfully"
                        store.dispatch("getBooks", {search: this.search, 
                                            option: this.option});                        
                    }
                    else if(response.status == 404){
                        this.error["deleteFaliure"] = "Book not found."
                    }
                })
            }
        }, 
        computed: {
            books(){
                return store.getters.getBooks;
            }
        },     
    }
</script> 