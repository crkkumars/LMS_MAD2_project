<script setup>
    import InputError from "@/components/InputError.vue";
import SuccessAlert from "@/components/SuccessAlert.vue";
import store from "@/store";
</script>
<template>
    <SuccessAlert :message="message"/>
    <div class="card create-section">
        <div class="card-body">
            <form @submit="createSection">
                <div class="mb-3">
                    <label for="SectionName" class="form-label">Section Name</label>
                    <input type="text" class="form-control" id="SectionName" v-model="name"
                        placeholder="Section Name">
                    <InputError :value="error['name']"/>
                </div>
                <div class="mb-3">
                    <label for="SectionDescription" class="form-label">Section Description</label>
                    <input type="text" class="form-control" id="SectionDescription" v-model="description"
                        placeholder="Section Description">
                        <InputError :value="error['description']"/>
                </div>
                <div class="mb-3">
                    <label for="SectionDate Added" class="form-label">Section Date Added</label>
                    <input type="date" class="form-control" id="SectionDate Added" v-model="date"
                        placeholder="Section Date Added">
                        <InputError :value="error['date']"/>
                </div>   
                <div class="col" style="min-width: 10%;">
                    <label for="SectionGenres" class="form-label">Genres</label>
                        <select class="form-select" multiple v-model="sectionGenres">
                            <option v-for="genre in genres" :value="genre.id">{{ genre["type"] }}</option>
                        </select>
                </div>      
                <div class="mb-3" style="display: flex; justify-content: center;">
                    <input type="submit" class="btn btn-primary" value="Create" style="width: 25%;">
                </div>
            </form>
        </div>
    </div>
</template>
<script>
    export default{
        data(){
            return {
                name: null,
                description: null,
                date: null,
                sectionGenres: [],               
                error: {
                    name: null,
                    description: null,
                    genre: null,
                },
                message: null
            }
        },
        created(){
            store.dispatch("getGenres")
        },
        methods:{            
            validate(){
                let error = false;
                this.error = {
                    name: null,
                }
                if(!this.name){
                    error = true;
                    this.error["name"] = "Invalid title."
                }
                if(!this.description){
                    error=true;
                    this.error["description"] = "Invalid description"
                }
                return error;
            },
            createSection(event){
                event.preventDefault();
                if(!this.validate()){
                    let form = new FormData();
                    form.append("name", this.name);
                    form.append("description", this.description);
                    this.sectionGenres.forEach(x=> form.append("genre", x));
                    form.append("date", this.date);

                    fetch(store.getters.BASEURL+"/section/create", {
                        method: "POST",
                        headers:{
                            "Authentication-Token": store.getters.getToken
                        },
                        body:form
                    }).then(response =>{
                        return response.json()
                    }).then(data =>{
                        if(Object.keys(data).includes("error")){
                            let error = data["error"];
                            console.log(data)
                            if(error == "Invalid title"){
                                this.error["name"] = "Invalid title."
                            }
                            else if(error == "Invalid description"){
                                this.error["rating"] = "Invalid description."
                            }
                            else if(error == "Invalid genres"){
                                this.error["genre"] = "Invalid genres."
                            }
                        }else{
                            this.message = "Created section succesfully."
                        }
                    })
                }

            }
        },
        computed:{
            genres(){
                return store.getters.getGenres;
            }
        }
    }
</script>
<style scoped>
    .create-section{
        margin: 20px;
    }
</style>
