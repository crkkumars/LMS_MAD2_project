<script setup>
import DangerAlert from "@/components/DangerAlert.vue";
import store from "@/store";
import { RouterLink, RouterView } from "vue-router";

</script>
<template>
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
            <router-link class="navbar-brand" to="/admin">
                <img src="/favicon.svg" alt="Logo" width="30" height="24" class="d-inline-block align-text-top">
                LMS
            </router-link>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <router-link class="nav-link dropdown-toggle" to="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                      Section
                    </router-link>
                    <ul class="dropdown-menu">
                      <li><router-link class="dropdown-item" to="/admin/section/create">Create</router-link></li>
                      <li><router-link class="dropdown-item" to="/admin/section/search">Search</router-link></li>
                    </ul>
                </li>     
                <li class="nav-item dropdown">
                    <router-link class="nav-link dropdown-toggle" to="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                      Books
                    </router-link>
                    <ul class="dropdown-menu">
                      <li><router-link class="dropdown-item" to="/admin/book/create">Create</router-link></li>
                      <li><router-link class="dropdown-item" to="/admin/book/search">Search</router-link></li>
                    </ul>
                </li> 
                <li class="nav-item">
                  <a class="nav-link" href="#" @click="exportPdf">Export</a>
                </li>                                
            </ul>
            </div>
        </div>
    </nav>
    <RouterView/>
    <DangerAlert :message="error['export']"/>
</template>
<script>
  export default{
    data(){
      return{
        task_id: null,
        error:{
          export: null
        }
      }
    },
    methods:{
      exportPdf(){
        fetch(store.getters.BASEURL+"/export", {
                method: "GET",
                headers:{
                    "Authentication-Token": store.getters.getToken
                }
        }).then(response =>{
          if(response.status == 200)
            return response.json()
          return {}
        }).then(data =>{
          if(Object.keys(data).includes("id")){
            this.task_id = data["id"]
            console.log("this.task_id",this.task_id)
            this.getStatus()
          }
        })
      },
      getStatus(){
        console.log("this.task_id get status",this.task_id)
        fetch(store.getters.BASEURL+"/export?task="+this.task_id, {
                method: "GET",
                headers:{
                    "Authentication-Token": store.getters.getToken
                }
            }).then(response =>{
              if(response.status == 200){
                return response.json()
              }
              else{
                this.error['export'] = "Export job failed."
                return {}
              }
            }).then(data =>{
              if(Object.keys(data).includes("status")){
                console.log(data)
                if(data["status"] == "SUCCESS")
                {
                  open(store.getters.BASEURL+"/download?task="+this.task_id)
                }          
                else
                {
                  setTimeout(this.getStatus, 1000);
                }
              }
            })
      }

    }
  }
</script>