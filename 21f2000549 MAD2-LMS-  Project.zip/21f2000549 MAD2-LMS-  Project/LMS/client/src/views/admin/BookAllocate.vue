<script setup>
    import DangerAlert from "@/components/DangerAlert.vue";
import SuccessAlert from "@/components/SuccessAlert.vue";
import store from "@/store";
</script>
<template>
    <SuccessAlert :message="message"/>
    <DangerAlert :message="danger"/>
    
    <form @submit="allocateBook">
        <div class="row" style="padding: 20px 20px 20px ;">
            <div class="col">
                <label for="Title" class="form-label"> Book Title</label>
                <input type="text" class="form-control" id="Title" v-model="title"
                    placeholder="Book Title">
            </div>
            <div class="col">
                <label for="UserName" class="form-label"> User Name</label>
                <input type="text" class="form-control" id="Title" v-model="username"
                    placeholder="User First Name">
            </div>
        </div>
        <div class="row" style="padding: 20px 20px 20px ;">
            <div class="col">
                <label for="status" class="form-label">Status</label>
                    <select class="form-select"   v-model="bookStatus">
                     <option v-for="stat in status" :value="stat.status" >
                        {{ stat["status"] }}</option>
                    </select>
            </div>
            <div class="col">
                <label for="RequestedDate" class="form-label">Requested Date</label>
                <input type="date" class="form-control" id="RequestedDate" v-model="request_date"
                placeholder="Requested Date">
            </div>
        </div>
        <div class="row" style="padding: 20px 20px 20px ;">
          
            <div class="col">
                <label for="IssuedDate" class="form-label">Issued Date</label>
                <input type="date" class="form-control" id="IssuedDate" v-model="issue_date"
                placeholder="Issued Date">
            </div>
            <div class="col" style="display: flex; justify-content: right;">
                <input type="submit" class="btn btn-primary" value="Allocate" style="width: 25%;">
            </div>
        </div>        
    </form>
</template>
<script>
    export default{
        props: ["id"],
        data(){
            return {
                title: this.$route.query["title"],
                username:null,              
                bookStatus: this.$route.query["status"],
                request_date: null,
                issue_date:null,              
                message: null,
                danger: null
               
            }
        },
        created(){          
            store.dispatch("getStatus")                       
        },
        methods:{
                      
            validate(){
                let error = false;
                this.error = {
                    title: null,
                }              
                
                return error;
            },
            allocateBook(event){
                event.preventDefault();
                if(!this.validate()){
                    let form = new FormData();
                    form.append("title", this.title);
                    form.append("username", this.username);
                    form.append("request_date", this.request_date);
                    form.append("bookStatus", this.bookStatus);
                    form.append("issue_date", this.issue_date);
                    
            

                    fetch(store.getters.BASEURL+"/book/"+this.id+"/allocate", {
                        method: "POST",
                        headers:{
                            "Authentication-Token": store.getters.getToken
                        },
                        body:form
                    }).then(response =>{
                        return response.json()
                    }).then(data =>{
                        if(Object.keys(data).includes("error")){
                            let error = data["error"];
                            console.log(data)
                            if(error == "Invalid title"){
                                this.error["name"] = "Invalid title."
                            }                           
                            else {
                                this.danger = "Book already allocated."
                            }
                        }else{
                            this.message = "Allocated book successfully."
                        }
                    })
                }
            }
        },
        computed:{          
            
            status(){
                return store.getters.getStatus;
            },
                       
        }
    }
</script>
<style scoped>
    .allocate-book-section{
        margin: 20px;
    }
</style>
