<script setup>
    import DangerAlert from "@/components/DangerAlert.vue";
import InputError from "@/components/InputError.vue";
import SuccessAlert from "@/components/SuccessAlert.vue";
import store from "@/store";
</script>
<template>
    <SuccessAlert :message="message"/>
    <DangerAlert :message="error['invalid_id']"></DangerAlert>
    <div class="card update-section">
        <div class="card-body">
            <form @submit="updateSection">
                <div class="mb-3">
                    <label for="SectionName" class="form-label">Section Name</label>
                    <input type="text" class="form-control" id="SectionName" v-model="name"
                        placeholder="Section Name">
                    <InputError :value="error['name']"/>
                </div>
                <div class="mb-3">
                    <label for="SectionDescription" class="form-label">Section Description</label>
                    <input type="text" class="form-control" id="SectionDescription" v-model="description"
                        placeholder="Section Description ">
                        <InputError :value="error['description']"/>
                </div>
                <div class="mb-3">
                    <label for="SectionDateUpdated" class="form-label">Section Date updated</label>
                    <input type="date" class="form-control" id="SectionDateUpdated" v-model="date"
                        placeholder="Section Date Updated">
                        <InputError :value="error['date']"/>
                </div>                 
                <div class="mb-3" style="display: flex; justify-content: center;">
                    <input type="submit" class="btn btn-primary" value="Update" style="width: 25%;">
                </div>
            </form>
        </div>
    </div>
</template>
<script>
    export default{
        props: ["id"],
        data(){
            return {
                name: null,
                description: null,
                date:null,               
                error: {
                    name: null,
                    description: null,
                    date:null,
                    genre: null,
                    invalid_id: null,
                },
                message: null
            }
        },
        created(){
            this.name = this.$route.query.name;
            this.description = this.$route.query.description;
            // this.date = this.$route.query.date;
        },
        methods:{
            validate(){
                let error = false;
                this.error = {
                    name: null,
                    description: null,
                    date:null,
                    invalid_id: null,
                }
                if(!this.name){
                    error = true;
                    this.error["name"] = "Invalid name."
                }
                if(!this.description){
                    error = true;
                    this.error["description"] = "Invalid description."
                }
                if(!this.date){
                    error = true;
                    this.error["date"] = "Invalid date."
                }
                return error;
            },
            updateSection(event){
                event.preventDefault();
                if(!this.validate()){
                    fetch(store.getters.BASEURL+"/section/"+this.id+"/edit", {
                                        method: "POST",
                                        headers:{
                                            "Content-Type": "application/json",
                                            "Authentication-Token": store.getters.getToken
                                        },
                                        body:JSON.stringify({
                                            name: this.name,
                                            description: this.description,
                                            date: this.date,
                                           
                                        })
                                    }).then(response =>{
                                        return response.json();
                                    }).then(response =>{
                                        if(Object.keys(response).includes("error")){
                                            let error = response["error"]
                                            if(error == "Invalid name"){
                                                this.error["name"] = "Invalid name.";
                                            }
                                            else if(error == "Section not found."){
                                                this.error["invalid_id"] = "Invalid Section id."
                                            }
                                            else if(error == "Invalid description."){
                                                this.error["description"] = "Invalid Description."
                                            }
                                            else{
                                                this.error["date"] = "Invalid date.";
                                            }
                                        }
                                        else if(Object.keys(response).includes("message")){
                                            this.message = "Update Section succcessfully."
                                        }
                                    })
                }

            }
        }
    }
</script>
<style scoped>
    .create-venue-section{
        margin: 20px;
    }
</style>
