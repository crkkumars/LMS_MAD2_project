<script setup>
import DangerAlert from "@/components/DangerAlert.vue";
import InputError from "@/components/InputError.vue";
import SuccessAlert from "@/components/SuccessAlert.vue";
import store from "@/store";
import { RouterLink } from "vue-router";
</script>
<template>
    <SuccessAlert :message="deleteSuccess"/>
    <DangerAlert :message="error['deleteFaliure']"/>
    <form @submit="searchSection">
        <div class="row" style="margin: 20px;">
            <div class="col" style="min-width: 60%;">
                <input type="text" class="form-control" placeholder="Search" v-model="search" aria-label="Search">
                <InputError :value="error['search']"/>
            </div>
            <div class="col" style="min-width: 20%;">
                <select class="form-select" aria-label="Filter" v-model="option">
                    <option selected>Name</option>
                    <option>Description</option>                                                   
                </select>
            </div>
            
            <div class="col">
                <input type="submit" style="width: 100%;" class="btn btn-success" value="Search">
            </div>
        </div>
        <div class="card" v-for="section in sections" style="margin: 15px;">
            <div class="card-body" style="display: flex; align-items: center;">
                <div style="width: 60%;">
                    <h5 class="card-title">{{ section.name }}</h5>
                    <h6 class="card-subtitle mb-2 text-body-secondary">{{ section.description }}</h6>
                     
                </div>
                <div>
                    <router-link class="btn btn-outline-warning" role="button"
                        :to="{name: 'section-edit', params: {id: section.id}, query: {name: section.name, description: section.description,date:section.date }}"  
                        style="margin-right: 20px;color: black;border: 2px solid var(--bs-btn-hover-bg);">
                        Edit
                    </router-link>
                    <button class="btn btn-danger" @click="deleteSection(section.id)" >Delete</button>
                </div>
            </div>
        </div>
    </form>
</template>
<script>
    export default{
        data(){
            return{
                search: null,
                option: "Name",
                deleteSuccess: null,
                error: {
                    search: null,
                    deleteFaliure: null,
                }
            }
        },
        created(){
            store.dispatch("getGenres")
            store.dispatch("getSections", {search: this.search, 
                                            option: this.option
                                            });

                                       
            },                                    
        methods: {            
            searchSection(event){
                event.preventDefault()            
                    store.dispatch("getSections", {search: this.search, 
                                    option: this.option
                                    });
            },
            deleteSection(section_id){
                fetch(store.getters.BASEURL+"/section/"+section_id, {
                                        method: "DELETE",
                                        headers:{
                                            "Content-Type": "application/json",
                                            "Authentication-Token": store.getters.getToken
                                        },
                                    }).then(response =>{
                                        if(response.status == 200){
                                            this.deleteSuccess = "Deleted section successfully.";
                                            store.dispatch("getSection",
                                             {search: "_", option: "Name"});
                                        }
                                        else if(response.status == 404)
                                            this.error["deleteFaliure"] = "Section not Found."
                                    })
            }
        },
        computed: {
            sections(){
                return store.getters.getSections;
            },
            genres(){
                return store.getters.getGenres;
            }
        }
    }
</script>