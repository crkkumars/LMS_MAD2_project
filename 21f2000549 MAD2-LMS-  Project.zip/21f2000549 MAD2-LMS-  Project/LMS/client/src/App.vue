<script setup>
import store from "@/store";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.min.js";
import { RouterView } from 'vue-router';
</script>
<template>
  <RouterView />
</template>
<script>
 export default{
    created(){
      let user = JSON.parse(sessionStorage.getItem("user"));
      if(!user)
        user = {roles: [], token: null}
      store.commit("setToken", user);
    }
  }
</script>