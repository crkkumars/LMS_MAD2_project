import store from "@/store";
import { createRouter, createWebHistory } from "vue-router";

import Layout from "@/views/Layout.vue";
import RegisterView from "@/views/RegisterView.vue";
import AdminLayout from "@/views/admin/AdminLayout.vue";
import AdminDashboard from "@/views/admin/AdminDashboard.vue";
import BookCreate from "@/views/admin/BookCreate.vue";
import BookSearch from "@/views/admin/BookSearch.vue";
import SectionCreate from "@/views/admin/SectionCreate.vue";
import SectionEdit from "@/views/admin/SectionEdit.vue";
import SectionSearch from "@/views/admin/SectionSearch.vue";
import LoginView from "@/views/LoginView.vue";
import BookEdit from "@/views/admin/BookEdit.vue";
import BookAllocate from "@/views/admin/BookAllocate.vue";
import BookdeAllocate from "@/views/admin/BookdeAllocate.vue";
import UserLayout from "@/views/user/UserLayout.vue";
import UserBookSearch from "@/views/user/UserBookSearch.vue";
import UserRequestBook from "@/views/user/UserRequestBook.vue";
import UserBookDetails from "@/views/user/UserBookDetails.vue";

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: "/login",
      name: "login",
      component: LoginView,
    },
    {
      path: "/register",
      name: "register",
      component: RegisterView,
    },
    {
      path: "/",
      name: "home",
      component: Layout,
    },
    {
      path: "/admin",
      name: "admin-index",
      component: AdminLayout,
      children: [
        {
          path: "",
          name: "admin-dashboard",
          component: AdminDashboard,
        },
        {
          path: "section/create",
          name: "section-create",
          component: SectionCreate,
        },
        {
          path: "section/search",
          name: "section-search",
          component: SectionSearch,
        },
        {
          path: "section/:id/edit",
          name: "section-edit",
          component: SectionEdit,
          props: true,
        },
        {
          path: "book/create",
          name: "book-create",
          component: BookCreate,
        },
        {
          path: "book/search",
          name: "book-search",
          component: BookSearch,
        },
        {
          path: "book/:id/edit",
          name: "book-edit",
          component: BookEdit,
          props: true,
        },
        {
          path: "book/:id/allocate",
          name: "book-allocate",
          component: BookAllocate,
          props: true,
        },
        {
          path: "book/:id/deallocate",
          name: "book-deallocate",
          component: BookdeAllocate,
          props: true,
        },
      ],
    },
    {
      path: "/user",
      name: "user-index",
      component: UserLayout,
      children: [
        {
          path: "book/search",
          name: "user-book-search",
          component: UserBookSearch,
          props: true,
        },
        {
          path: "book/:id/request",
          name: "user-request-book",
          component: UserRequestBook,
          props: true,
        },
        {
          path: "book/details",
          name: "user-book-details",
          component: UserBookDetails,
          props: true,
        },
      ],
    },
  ],
});
router.beforeEach((to, from) => {
  if (
    (to.path == "/" || to.path.match("/admin*") || to.path.match("/user*")) &&
    !store.getters.getToken
  ) {
    return { name: "login" };
  }
  if (to.path.match("/admin*") && store.getters.getRoles.includes("user")) {
    return { name: "user-index" };
  }
  if (
    to.path.match("/admin*") &&
    !store.getters.getToken &&
    !store.getters.getRoles.includes("admin")
  ) {
    return { name: "login" };
  }
});

export default router;
