<template>
    <div>
        <h1>Download PDF</h1>
        <DownloadButton />
    </div>
</template>
