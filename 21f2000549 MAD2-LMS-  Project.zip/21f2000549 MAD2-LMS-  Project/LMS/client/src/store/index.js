import { createStore } from "vuex";

export default createStore({
  state() {
    return {
      BASEURL: "http://127.0.0.1:5000",
      sections: [],
      genres: [],
      status: [],
      books: [],
      category: [],
      mybooks: [],
      user: {
        roles: [],
        token: null,
      },
    };
  },
  getters: {
    BASEURL(state) {
      return state.BASEURL;
    },
    getToken(state) {
      return state.user["token"];
    },
    getRoles(state) {
      return state.user["roles"];
    },
    getSections(state) {
      return state.sections;
    },
    getGenres(state) {
      return state.genres;
    },
    getStatus(state) {
      return state.status;
    },
    getCategory(state) {
      return state.category;
    },
    getBooks(state) {
      return state.books;
    },
    getMyBooks(state) {
      return state.mybooks;
    },
  },
  mutations: {
    setToken(state, value) {
      state.user = value;
      sessionStorage.setItem("user", JSON.stringify(value));
    },
    setSections(state, sections) {
      state.sections = sections;
    },
    setGenres(state, value) {
      state.genres = value;
    },
    setStatus(state, value) {
      state.status = value;
    },
    setCategory(state, value) {
      state.category = value;
    },
    setBooks(state, value) {
      state.books = value;
    },
    setMyBooks(state, value) {
      state.mybooks = value;
    },
  },
  actions: {
    getSections({ commit, state }, { search, option }) {
      fetch(state.BASEURL + "/section/search", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authentication-Token": state.user["token"],
        },
        body: JSON.stringify({
          search: search,
          option: option,
        }),
      })
        .then((response) => {
          if (response.status == 200) return response.json();
          return [];
        })
        .then((data) => {
          commit("setSections", data);
        });
    },
    getGenres({ commit, state }) {
      fetch(state.BASEURL + "/genre", {})
        .then((response) => {
          if (response.status == 200) return response.json();
          return [];
        })
        .then((data) => {
          commit("setGenres", data);
        });
    },
    getStatus({ commit, state }) {
      fetch(state.BASEURL + "/status", {})
        .then((response) => {
          if (response.status == 200) return response.json();
          return [];
        })
        .then((data) => {
          commit("setStatus", data);
        });
    },
    getCategory({ commit, state }) {
      fetch(state.BASEURL + "/category", {})
        .then((response) => {
          if (response.status == 200) return response.json();
          return [];
        })
        .then((data) => {
          commit("setCategory", data);
        });
    },
    getBooks({ commit, state }, { search, option }) {
      const query = new URLSearchParams();
      if (search) query.append("search", search);
      if (option) query.append("option", option);
      fetch(state.BASEURL + "/books?" + query.toString(), {
        method: "GET",
        headers: {
          "Authentication-Token": state.user["token"],
        },
      })
        .then((response) => {
          return response.json();
        })
        .then((data) => {
          commit("setBooks", data);
        });
    },
    getMyBooks({ commit, state }) {
      fetch(state.BASEURL + "/getmybooks", {
        method: "GET",
        headers: {
          "Authentication-Token": state.user["token"],
        },
      })
        .then((response) => {
          if (response.status == 200) return response.json();
          return [];
        })
        .then((data) => {
          commit("setMyBooks", data);
        });
    },
  },
});
