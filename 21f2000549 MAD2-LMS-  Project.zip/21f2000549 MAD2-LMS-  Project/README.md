
# Library Management System

 Library Management System v2 is a multi-user application to issue e-book. Users can read, request and return e-book.Librarian can add new sections/e-books, issue/revoke access for a book.

###

### Features : 

General User signup and login (using RBAC)
User and admin should be authenticated using username or email and password
Use Flask Security or JWT based Token Based Authentication only
General User Profile
Registration form for General User 
Download e-books
Mandatory Librarian Login (using RBAC)
Librarian Dashboard
Section Management
Book Management
Search functionality for sections/e-books 
Backend Jobs
Export Jobs
Reporting Jobs
Alert Jobs
Backend Performance

##
### Technologies Used : 

Flask for API
VueJS for UI 
Jinja2 templates
Bootstrap
Redis and Celery for batch jobs and Scheduling
SQLite and SqlAlchemy for data storage.


### Installation
# Library Management System
## create virtual enviroment

command: pip install virtualenv
command: virtualenv <venv_name>

# Install the requirements 
 
pip install -r requirements.txt


# Run the application. 

flask run --debug

#Clone the repository.

https://github.com/crkkumars/Grocerystore-Mad1.git

# Create Vue Client UI
npm create vue@latest    # Create client

#Install node modules

npm install vuex@next
npm install bootstrap@5.3.3  
npm install vue3-apexcharts 
npm install              # install the packages

#run Vue client

npm run dev  

#delete Instance

rm -r instance 

# Start Celery Redis server

sudo service redis-server start

# Run celery
celery -A app:celery worker --loglevel=INFO --pool=solo









